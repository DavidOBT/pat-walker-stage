#!/usr/bin/env python3
"""slice_scene.py -- cut one scene's Gladsbuy print files out of two layer images.

  python3 slice_scene.py --portal sweets-portal.png --drop sweets-drop.png --out sweets/ [--mask sweets-canopy-mask.png]

portal : the 62 x 25 ft portal layer, any resolution (px per ft = width / 62). What sits in the opening is ignored.
drop   : the 50 x 25 ft drop (2:1). Optional.
mask   : optional canopy cut mask, same size as the portal image: white = fabric stays, black = cut away.
         Without it the cut follows the arch (16 ft at the legs, 20 ft at centre).
Writes, at the portal's resolution: canopy-62x10.jpg, portal-leg-HL/HR-11x25.jpg, upstage-leg-HL/HR-12x25.jpg, drop-50x25.jpg, manifest.json
The cut-away area is printed plum with a 1-inch plum band just inside the fabric edge (the cut guide)."""
import argparse, json, math, os
from PIL import Image, ImageFilter
PLUM = (58, 18, 80)
ap = argparse.ArgumentParser(); ap.add_argument('--portal', required=True); ap.add_argument('--drop'); ap.add_argument('--out', default='slices'); ap.add_argument('--mask'); a = ap.parse_args()
os.makedirs(a.out, exist_ok=True)
por = Image.open(a.portal).convert('RGB'); W, H = por.size; ppf = W / 62.0
if abs(H - 25 * ppf) > 0.01 * H: por = por.resize((W, int(round(25 * ppf))), Image.LANCZOS); H = por.height; print('note: resized to 62:25')
if ppf < 200: print(f'warning: {ppf:.0f} px/ft is under the 200 px/ft floor for the portal pieces')
ft = lambda v: int(round(v * ppf))
# canopy
can = por.crop((0, 0, W, ft(10)))
if a.mask: m = Image.open(a.mask).convert('L').resize(por.size, Image.NEAREST).crop((0, 0, W, ft(10))).point(lambda p: 255 if p > 127 else 0)
else:
    m = Image.new('L', can.size, 255); px = m.load()
    for x in range(ft(11), ft(51)):
        xc = (x - W / 2) / ppf; yb = ft(25 - (16 + 4 * math.sqrt(max(0.0, 1 - (xc / 20) ** 2))))
        for y in range(yb, can.height): px[x, y] = 0
k = 2 * max(1, int(round(ppf / 12))) + 1
inner = m.filter(ImageFilter.MinFilter(k))            # fabric eroded by 1 inch
band = Image.composite(Image.new('L', m.size, 255), Image.new('L', m.size, 0), m).point(lambda p: p) ; band.paste(0, mask=inner)
out = Image.composite(can, Image.new('RGB', can.size, PLUM), m)   # cut-away -> plum
out.paste(PLUM, mask=band)                                          # 1-inch plum band inside the edge
out.save(f'{a.out}/canopy-62x10.jpg', quality=92)
# legs
crops = {'upstage-leg-HL-12x25': (0, 0, ft(12), H), 'portal-leg-HL-11x25': (0, 0, ft(11), H),
         'upstage-leg-HR-12x25': (W - ft(12), 0, W, H), 'portal-leg-HR-11x25': (W - ft(11), 0, W, H)}
for n, box in crops.items(): por.crop(box).save(f'{a.out}/{n}.jpg', quality=92)
man = dict(px_per_ft=round(ppf, 1), canopy=[W, ft(10)], upstage_leg=[ft(12), H], portal_leg=[ft(11), H], note='HL = house left. Leg tops (10 ft) hang hidden behind the canopy.')
if a.drop:
    d = Image.open(a.drop).convert('RGB'); tw, th = ft(50), ft(25)
    if d.size != (tw, th): d = d.resize((tw, th), Image.LANCZOS)
    d.save(f'{a.out}/drop-50x25.jpg', quality=92); man['drop'] = [tw, th]
json.dump(man, open(f'{a.out}/manifest.json', 'w'), indent=1); print(json.dumps(man, indent=1))
