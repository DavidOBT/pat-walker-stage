NUTCRACKER 2026 SET TEMPLATES  (OBT, Pat Walker Theater, Dec 18-20 2026)
One kit serves all three scenes: the pieces are the same size in every scene; only the pictures change.

COORDINATES  Templates are drawn in inches from the top-left of each piece, y down. Rasters are 100 px per foot
(8.33 px per inch). The SVGs open in Illustrator/Affinity/Inkscape as guide layers; the PNGs drop onto an art canvas
of the same size or into an image generator as a reference/overlay layer.

FILES
  portal-layer-62x25.svg/.png   the front layer: canopy border + both leg zones, transparent opening. Draw the portal here.
  drop-layer-50x25.svg/.png     the back layer: the printed drop with story / finish zones and the visible-top curves.
  canopy-border-62x10.svg/.png  the canopy piece alone (same geometry as the top of the portal layer).
  leg-12x25-house-left/right    one leg design zone (12 ft). The 11-ft portal leg is this design minus the onstage foot.
  preview-stack.jpg             how the two layers sit: drop behind, portal in front.
  geometry.json                 every number, machine-readable (arch table, pixel sizes, pipe stack).
  slice_scene.py                cuts the six print files out of your finished portal + drop images (see its header).

THE ARCH (canopy bottom, ft above deck, x = ft from centre)   y = 16 + 4 * sqrt(1 - (x/20)^2)
  x =  0 ft   bottom  20.0 ft   ( 60.0 in from the top of the piece)
  x =  2 ft   bottom 19.98 ft   ( 60.2 in from the top of the piece)
  x =  4 ft   bottom 19.92 ft   ( 61.0 in from the top of the piece)
  x =  6 ft   bottom 19.82 ft   ( 62.2 in from the top of the piece)
  x =  8 ft   bottom 19.67 ft   ( 64.0 in from the top of the piece)
  x = 10 ft   bottom 19.46 ft   ( 66.4 in from the top of the piece)
  x = 12 ft   bottom  19.2 ft   ( 69.6 in from the top of the piece)
  x = 14 ft   bottom 18.86 ft   ( 73.7 in from the top of the piece)
  x = 16 ft   bottom  18.4 ft   ( 79.2 in from the top of the piece)
  x = 18 ft   bottom 17.74 ft   ( 87.1 in from the top of the piece)
  x = 20 ft   bottom  16.0 ft   (108.0 in from the top of the piece)

PIXEL SIZES (width x height)          100 px/ft (working)   200 px/ft (print floor)   500 px/ft (Gladsbuy asks)
  portal layer 62 x 25 ft             6200 x 2500           12400 x 5000              31000 x 12500
  canopy border 62 x 10 ft            6200 x 1000           12400 x 2000              31000 x 5000
  portal leg 11 x 25 ft               1100 x 2500           2200 x 5000               5500 x 12500
  upstage leg 12 x 25 ft              1200 x 2500           2400 x 5000               6000 x 12500
  drop 50 x 25 ft                     5000 x 2500           10000 x 5000              25000 x 12500

ASPECT RATIOS FOR GENERATION  drop 2:1 · leg 12:25 (generate 1:2 and crop) · canopy units: centre motif 14x10 (7:5),
swag unit 12x10 (6:5). Generate units at 2000 px wide or more, upscale 2x, assemble on the portal layer, then slice.

WORKFLOW  1 paint/generate the drop full-frame on the drop layer  2 paint/generate the portal on the portal layer with the
opening left plum or transparent  3 stack them to preview (preview-stack shows the alignment: drop offset 6 ft = 600 px)
4 python3 slice_scene.py --portal X.png --drop Y.png --out scene/  5 send the six files to Gladsbuy with size in the name.

SEATS  visibility zones use the model's placeholder house: row-5 eye 2 ft above the deck, 36 ft from plaster, widest seat
20 ft off centre. Re-run the model when the real numbers are measured.
